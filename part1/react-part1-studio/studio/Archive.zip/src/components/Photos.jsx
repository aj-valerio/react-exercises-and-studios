import styles from './Description.module.css';

export default function RecipePhoto(){
   return (
   <div>
        <img src="https://sallysbakingaddiction.com/wp-content/uploads/2013/05/classic-chocolate-chip-cookies.jpg" alt="chocolate chip cookies" className = {styles.imageUpdates} />
    </div>);
}